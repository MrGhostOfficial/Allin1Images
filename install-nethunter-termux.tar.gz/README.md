# Easy to install kalilinux in termux
$ cat -n README.md
$ rm -rf kali-arm64

$ pkg update

$ pkg install curl -y;pkg install wget -y;pkg install zip -y;pkg install unzip -y;pkg install tar -y;pkg install root-repo;pkg install x11-repo;pkg install tsu -y;pkg install neofetch -y;pkg install termux-api;pkg install cowsay -y;pkg install jp2a -y

$ cp -rf /sdcard/download/kalifs-arm64-full.tar.xz $HOME

$ tar -xvzf install-nethunter-termux.tar.gz;rm -rf install-nethunter-termux.tar.gz;mv -v bash.bashrc $PREFIX/etc;mv -v ighostcontact ikalihelp neofetch $PREFIX/bin;clear;ls
$ ./install-nethunter-termux

$ tar -xvzf kali-arm64.tar.gz;rm -rf kali-arm64.tar.gz

$ rm -rf README.md install-nethunter-termux kalifs-arm64-full.tar.xz

$ ikalihelp
$ sudo apt update
$ sudo apt install neofetch -y
$ sudo apt full-upgrade -y